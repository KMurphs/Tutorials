# Using Wordpress with React.js

This is a react application which works as a front-end for a Wordpress site. Our data is being provided by the TechCrunch.com website. The accompanying blog post can be found [here](https://www.iamtimsmith.com/blog/using-wordpress-with-react/).
