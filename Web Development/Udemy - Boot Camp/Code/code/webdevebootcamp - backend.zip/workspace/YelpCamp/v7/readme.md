RESTFUL Routes

name        url             verb            description
=======================================================
INDEX       /dogs           GET             Displays a list of dogs
NEW         /dogs/new       GET             Dispays a form to add a new dog
CREATE      /dogs           POST            Add a new dog to db
SHOW        /dogs/:id       GET             Shows nfo about one dog
