RESTFUL Routes

name        url             verb            description
=======================================================
INDEX       /dogs           GET             Displays a list of dogs
NEW         /dogs/new       GET             Dispays a form to add a new dog
CREATE      /dogs           POST            Add a new dog to db
SHOW        /dogs/:id       GET             Shows nfo about one dog



Authentication: Find out whether someone is who they say they are
Authorization: Find out whether someone has the rights/privileges do perfrom certain action - Permissions


void(0), or void(anyting) will give you the undefined value/state