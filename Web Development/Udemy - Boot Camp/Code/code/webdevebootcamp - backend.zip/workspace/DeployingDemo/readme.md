Using Heroku to deploy a simple app on a cloud server
Heroku seems to be just like AWS


Heroku website provides a step by step process on how to do this
but i will dcument what we did here!

- Create a FREE account with Heroku (FREE just because we don't have to pay)
- Ensure that the app directory on c9 (our machine) is a GIT repository
        git init
        git add .
        git commit -m "Initial Commit"
- Heroku Create (it created some spacae on their server for my app)
        https://frozen-meadow-26423.herokuapp.com
- The last command also created a second repository (like GitHUB?) where
        I can push and fetch from.
        git remote -v
- git push heroku master
- heroku logs, heroku logs --tail
- This generate an error because it does not know how to start the app.
        So add in package.json, in scripts, a new entry (after the test key/value)
        "start": "node app.js"
        save all
        git add .
        git commit 
        git push heroku master



Note:

heroku run ls
heroku run ls node_modules/
These allow you to look at the directory on huroku for files, folders,...
or
heroku run npm install --save mongoose