console.log("MEOUW!!")

// git add .
// this stages evrything for commit


// git init
// git status

// git add .
// git commit -m ""


// git log - use arrow to move (up and down), use q to quit. the oldest commit is the one at the bottom tbottom

// git checkout <id of commit> goes back in time, then we get the following:
    //          HEAD (at the revision specified by <id of commit>)
    // O -> O -> O -> O -> O -> O -> O -> 0
    //                                    MASTER (Which is the main, current, newest, more recetn copy)
    
    //with that you ca have a look at what you did, copy stuff because your goals is to go back in master and work there
    //you do that with 
    //git checkout master
    
// https://stackoverflow.com/questions/4114095/how-to-revert-a-git-repository-to-a-previous-commit
// In order to make a older version become the master
// git revert --no-commit 0766c053..HEAD
// git commit
// This will not erase anything. this will just add a new entry in the log where everything looks exactly 
// like that previoius copy that we wanted to go back to. But also the log entry before that is exactly
// the state of the repository at the moment we decided to revert back.
// so if we wanted to actually undo the reversion, we could just checkout at the entry just before


// more on GIT
// https://www.youtube.com/watch?v=LemSseuZB9I&list=PL86ehqHzxhy4XX_qZZE_5mrp38WGZRzTO
    
