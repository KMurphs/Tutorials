function echo(msg, repeat){
    for(var i = 0; i < repeat; i++)
        console.log(msg);
}

echo("Echo!!!", 10);
echo("Tater Tots", 3);