var cat = require("cat-me"); //obtain the package handle in the variable
var joke = require("knock-knock-jokes");


console.log(cat()); // use the variable thereafter
console.log(joke()); // use the variable thereafter